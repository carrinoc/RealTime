/*
    Run the code using Sudo ./capture
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <time.h>
#include <iostream>
#include <string>
#include <sys/time.h>
#include <time.h>
#include <ctime>
#include <queue>

#include "opencv2/opencv.hpp"
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#define num_frames 60
#define NUM_CPU_CORES (3)
#define NUM_THREADS (3+1)
#define NANOSEC_PER_SEC (1000000000)

using namespace cv;
using namespace std;

sem_t semS1, semS2, semS3;
struct timeval start_time_val;

bool abort1 = false, abort2 = false, abort3 = false;
int picNum = 0;

// Queue for all the frames taken
std::queue<std::pair<cv::Mat, double>> takenFrames;

// Queue for frames ready to be saved
std::queue<std::pair<cv::Mat, double>> framesToSave;

// Structure for the thread information
typedef struct
{
    int threadIdx;
    unsigned long long sequencePeriods;
} threadParams_t;

// Initialize the functions
void *capture(void *threadp);
void *Sequencer(void *threadp);
void *imgSort(void *threadp);
void *imgSave(void *threadp);

int main(int argc, char **argv)
{
    struct timeval current_time_val;
    int i, rc, scope;
    cpu_set_t threadcpu;
    pthread_t threads[NUM_THREADS];
    threadParams_t threadParams[NUM_THREADS];
    pthread_attr_t rt_sched_attr[NUM_THREADS];
    int rt_max_prio, rt_min_prio;
    struct sched_param rt_param[NUM_THREADS];
    struct sched_param main_param;
    pthread_attr_t main_attr;
    pid_t mainpid;
    cpu_set_t allcpuset;

    CPU_ZERO(&allcpuset);

    for(i=0; i < NUM_CPU_CORES; i++)
       CPU_SET(i, &allcpuset);

    printf("Using CPUS=%d from total available.\n", CPU_COUNT(&allcpuset));

    // Initalize the necessary semaphores
    if (sem_init (&semS1, 0, 0)) { printf ("Failed to initialize S1 semaphore\n"); exit (-1); }
    if (sem_init (&semS2, 0, 0)) { printf ("Failed to initialize S2 semaphore\n"); exit (-1); }
    if (sem_init (&semS3, 0, 0)) { printf ("Failed to initialize S3 semaphore\n"); exit (-1); }

    mainpid=getpid();

    rt_max_prio = sched_get_priority_max(SCHED_FIFO);
    rt_min_prio = sched_get_priority_min(SCHED_FIFO);

    rc=sched_getparam(mainpid, &main_param);
    main_param.sched_priority=rt_max_prio;
    rc=sched_setscheduler(getpid(), SCHED_FIFO, &main_param);
    if(rc < 0) perror("main_param");   

    pthread_attr_getscope(&main_attr, &scope);

    CPU_ZERO(&threadcpu);

    for(i=0; i < NUM_THREADS; i++)
    {
        // Set the CPU Cores to use for the threads
        if(i < NUM_CPU_CORES)
            CPU_SET(i, &threadcpu);

        rc=pthread_attr_init(&rt_sched_attr[i]);
        rc=pthread_attr_setinheritsched(&rt_sched_attr[i], PTHREAD_EXPLICIT_SCHED);
        rc=pthread_attr_setschedpolicy(&rt_sched_attr[i], SCHED_FIFO);
        rc=pthread_attr_setaffinity_np(&rt_sched_attr[i], sizeof(cpu_set_t), &threadcpu);

        rt_param[i].sched_priority=rt_max_prio-i;
        pthread_attr_setschedparam(&rt_sched_attr[i], &rt_param[i]);
    }
     
    printf("Service threads will run on %d CPU cores\n", CPU_COUNT(&threadcpu));

    // Capture = RT_MAX-1	@ 1 Hz
    rt_param[1].sched_priority=rt_max_prio-1;
    pthread_attr_setschedparam(&rt_sched_attr[1], &rt_param[1]);
    rc=pthread_create(&threads[1],               // pointer to thread descriptor
                      &rt_sched_attr[1],         // use specific attributes
                      //(void *)0,               // default attributes
                      capture,                   // thread function entry point
                      (void *)&(threadParams[1]) // parameters to pass in
                     );
    if(rc < 0)
        perror("pthread_create for service 1");
    else
        printf("pthread_create successful for service 1\n");

    // Sort Images = RT_MAX-1	@ 1 Hz
    rt_param[2].sched_priority=rt_max_prio-2;
    pthread_attr_setschedparam(&rt_sched_attr[2], &rt_param[2]);
    rc=pthread_create(&threads[2],               // pointer to thread descriptor
                      &rt_sched_attr[2],         // use specific attributes
                      //(void *)0,               // default attributes
                      imgSort,                   // thread function entry point
                      (void *)&(threadParams[2]) // parameters to pass in
                     );
    if(rc < 0)
        perror("pthread_create for service 2");
    else
        printf("pthread_create successful for service 2\n");

    // Save Images = RT_MAX-1	@ 1 Hz
    rt_param[3].sched_priority=rt_max_prio-3;
    pthread_attr_setschedparam(&rt_sched_attr[3], &rt_param[3]);
    rc=pthread_create(&threads[3],               // pointer to thread descriptor
                      &rt_sched_attr[3],         // use specific attributes
                      //(void *)0,               // default attributes
                      imgSave,                   // thread function entry point
                      (void *)&(threadParams[3]) // parameters to pass in
                     );
    if(rc < 0)
        perror("pthread_create for service 3");
    else
        printf("pthread_create successful for service 3\n");

    threadParams[0].sequencePeriods=30*60*10;

    // Sequencer = RT_MAX	@ 30 Hz
    //
    rt_param[0].sched_priority=rt_max_prio;
    pthread_attr_setschedparam(&rt_sched_attr[0], &rt_param[0]);
    rc=pthread_create(&threads[0], &rt_sched_attr[0], Sequencer, (void *)&(threadParams[0]));
    if(rc < 0)
        perror("pthread_create for sequencer service 0");
    else
        printf("pthread_create successful for sequencer service 0\n");

    for(i=0;i<NUM_THREADS;i++)
       pthread_join(threads[i], NULL);

    printf("\nTEST COMPLETE\n");
}

void *Sequencer(void *threadp)
{

    struct timeval current_time_val;
    struct timespec delay_time = {0,41666667}; // delay for 33.33 msec, 30 Hz {currently 24hz}
    struct timespec remaining_time;
    double current_time;
    double residual;
    int rc, delay_cnt=0;
    unsigned long long seqCnt=0;
    threadParams_t *threadParams = (threadParams_t *)threadp;

    do{
        {
            rc=nanosleep(&delay_time, &remaining_time);

            if(rc == EINTR)
            { 
                residual = remaining_time.tv_sec + ((double)remaining_time.tv_nsec / (double)NANOSEC_PER_SEC);

                if(residual > 0.0) printf("residual=%lf, sec=%d, nsec=%d\n", residual, (int)remaining_time.tv_sec, (int)remaining_time.tv_nsec);
 
                delay_cnt++;
            }
            else if(rc < 0)
            {
                perror("Sequencer nanosleep");
                exit(-1);
            }
           
        } while((residual > 0.0) && (delay_cnt < 100));

        seqCnt++;

        if(delay_cnt > 1) printf("Sequencer looping delay %d\n", delay_cnt);

        // Release each service at a sub-rate of the generic sequencer rate

        // Capture the image = RT_MAX-1	@ 1 Hz
        if((seqCnt % 24) == 0) sem_post(&semS1);

        // Sort the images = RT_MAX-1	@ 1 Hz
        if((seqCnt % 24) == 0) sem_post(&semS2);

        // Save the images = RT_MAX-1	@ 1 Hz
        if((seqCnt % 24) == 0) sem_post(&semS3);

    }while(seqCnt < threadParams->sequencePeriods);

    // Break while loop in services and release semaphores
    abort1 = true; abort2 = true; abort3 = true;
    sem_post(&semS1);  sem_post(&semS2);  sem_post(&semS3);
}   

// Capture the images
void *capture(void *threadp)
{
    Mat img, grayImg;
    VideoCapture cap(0);
    
    time_t start, end;
    double timeDiff;

    time(&start);

    while(!abort1)
    {    
        // Take the image
        sem_wait(&semS1);
        cap >> img;

        // Calculate the time that has passed
        // TODO: Fix the timing so its not just in seconds
        time(&end);
        timeDiff = difftime(end, start);

        // Add the image and time to the queue
        takenFrames.push(std::pair<cv::Mat, double>(img, timeDiff));
    }

    cap.release();
}

// Sort through images to ensure no doubles 
void *imgSort(void *threadp) 
{
    Mat firstImg, secondImg, firstGray, secondGray, diffImg;
    double time;

    while(!abort2)
    {
        sem_wait(&semS2);

        // Check that there are 2 images to compare
        // TODO: How to process last image taken 
        if(takenFrames.size() >= 2)
        {
            // Get the first image and make it gray
            firstImg = takenFrames.front().first;
            time = takenFrames.front().second;
            cvtColor(firstImg, firstGray, CV_BGR2GRAY);
            takenFrames.pop();

            // Get the second image and make it gray
            secondImg = takenFrames.front().first;
            cvtColor(secondImg, secondGray, CV_BGR2GRAY);

            // Compare the images
            bitwise_and(firstGray, secondGray, diffImg);

            // If they are different, add the image and its time to the save queue
            // TODO: Check if this correctly works
            if(countNonZero(diffImg) != 0)
                framesToSave.push(std::pair<cv::Mat, double>(firstImg, time));
        }
    }
}

// Save the images as ppm files
void *imgSave(void *threadp)
{
    Mat img;
    double time;

    while(!abort3)
    {
        sem_wait(&semS3);
        
        // If there are images to save
        if(!framesToSave.empty())
        {
            // Get the image and its time
            img = framesToSave.front().first;
            time = framesToSave.front().second;
            framesToSave.pop();

            // Add the time to the image
            putText(img, to_string(time), cvPoint(30,30), FONT_HERSHEY_COMPLEX_SMALL, 0.8, cvScalar(200,200,250), 1, CV_AA);

            // Set parameters for a ppm file
            vector<int> compression_params;
            compression_params.push_back(CV_IMWRITE_PXM_BINARY);
            compression_params.push_back(9);

            // Make the name for the photo
            string photoName = "clock" + to_string(picNum)+".ppm";

            try
            {
                // Make the image
                imwrite(photoName, img, compression_params);
            }

            catch(runtime_error& ex)
            {
                // Error making the image
                fprintf(stderr, "exception converting image to PPM format: %s\n", ex.what());
                return (void *)-1;
            }

            // Increase the picture number for the name            
            picNum++;
        }
    }
}